select count(distinct affcity, affcountry)
from Affiliations
where affname='University of California';